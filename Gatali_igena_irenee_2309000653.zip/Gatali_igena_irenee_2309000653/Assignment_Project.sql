    CREATE database Mental_Heath_Support;
use Mental_Heath_Support;
CREATE TABLE Users (
    UserID INT PRIMARY KEY ,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Phone VARCHAR(255) NOT NULL
);

CREATE TABLE Sessions (
    SessionID INT PRIMARY KEY ,
    UserID INT NOT NULL,
    StartTime DATE,
    EndTime DATE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID) 
);
CREATE TABLE Messages (
    MessageID INT PRIMARY KEY ,
    UserID INT NOT NULL,
    SessionID INT NOT NULL,
    MessageText TEXT NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ,
    FOREIGN KEY (SessionID) REFERENCES Sessions(SessionID) 
);
CREATE TABLE Feedbacks (
    FeedbackID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT NOT NULL,
    SessionID INT NOT NULL,
    Comments text,
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ,
    FOREIGN KEY (SessionID) REFERENCES Sessions(SessionID) 
);
-- insert in Users

insert into Users values(1,"gatali","gatali@.com","0780126041"),
(2,"irenee","irenee@.com","0780121233"),
(3,"igeno","igeno@.com","0723126041");

-- inset in Sessions

insert into Sessions values(01,1,"25-1-2023","22-1-2025"),
(02,2,"20-2-2023","22-2-2025"),
(03,3,"12-1-2024","25-2-2025");

-- insert in messages

insert into Messages values(11,1,01,"welcome"),
(12,2,02,"how to make"),
(13,3,03,"mental health");

-- insert in feedback

insert into Feedbacks values(44,1,01,"thanks "),
(55,2,02,"welcome back "),
(66,3,03,"came to see");

select * from Users;
select * from Messages;
select * from Sessions;
select * from Feedbacks;

alter table Sessions
drop column StartTime;

alter table Sessions
drop column EndTime;

alter table Sessions
add column StartTime date ;

desc Sessions;

alter table Sessions
add column EndTime date ;

update  Sessions
set StartTime="22-2-2024,00-00-00"
where SessionID=01;
-- select 

SELECT u.Name, u.Email, u.Phone, f.Comments,
m.MessagText
FROM Users u
JOIN Messages m ON u.UserID = u.UserID
JOIN Feedbacks f ON u.UserID = u.UserID
WHERE u.UserID >= 2;
-- counting

SELECT m.SessionID, COUNT(f.UserID)
AS Feedbacks
FROM Messages
LEFT JOIN Feedbacks f ON m.MessageText=
m.MessageText;
select count(FeedbackID) from Feedbacks;
select count(SessionID) from Sessions;
select count(Name) from Users;
select count(MessageText) from Messages;
-- update
update Users
set Name="Rushibura"
where UserID=2;

select * from Users;

update Messages
set MessageText="university "
where MessageID=12;
select * from Messages;

update Feedbacks
set Comments="don't drink"
where FeedbackID=44;

select * from Feedbacks;
-- average

SELECT Name, AVG (UserID) as Average
FROM Users
GROUP BY Name;
-- sum
SELECT Email, sum(UserID) as sum
FROM Users
GROUP BY Email;
-- create view

CREATE VIEW ListUsers as
SELECT * FROM Users
-- procedure
-- Insert Data Using a Stored Procedure
DELIMITER $$
CREATE PROCEDURE Adduse(
    IN UserIDparam int  , 
    IN Nameparam VARCHAR(50), 
    IN EmailParam VARCHAR(70), 
    IN PhoneParam VARCHAR(100)
)
BEGIN
    INSERT INTO Users VALUES (UserIDParam, NameParam, EmailParam, PhoneParam);
END $$
DELIMITER ;

CALL Adduse(4, 'Dev', 'dev@.com', 07354278);
select * from Users;
DELIMITER $$

-- Procedure to add a new user
CREATE PROCEDURE AddUser(
    IN UserIDParam INT, 
    IN NameParam VARCHAR(100), 
    IN EmailParam VARCHAR(255), 
    IN PhoneParam VARCHAR(255)
)
BEGIN
    INSERT INTO Users (UserID, Name, Email, Phone) 
    VALUES (UserIDParam, NameParam, EmailParam, PhoneParam);
END $$
CALL AddUser(4, 'John Doe', 'john.doe@example.com', '0712345678');
DErimiter;
-- Procedure to add a new session
DELIMITER $$
CREATE PROCEDURE AddSession(
    IN SessionIDParam INT, 
    IN UserIDParam INT, 
    IN StartTimeParam DATE, 
    IN EndTimeParam DATE
)
BEGIN
    INSERT INTO Sessions (SessionID, UserID, StartTime, EndTime) 
    VALUES (SessionIDParam, UserIDParam, StartTimeParam, EndTimeParam);
END $$
CALL AddSession(4, 4, '2024-02-01', '2024-02-10');
DELIMITER;
-- Procedure to add a new message
DELIMITER $$
CREATE PROCEDURE AddMessage(
    IN MessageIDParam INT, 
    IN UserIDParam INT, 
    IN SessionIDParam INT, 
    IN MessageTextParam TEXT
)
BEGIN
    INSERT INTO Messages (MessageID, UserID, SessionID, MessageText) 
    VALUES (MessageIDParam, UserIDParam, SessionIDParam, MessageTextParam);
END $$
CALL AddMessage(14, 4, 4, 'Hello, this is a test message');
DELIMITER;
-- Procedure to add feedback
DELIMITER $$
CREATE PROCEDURE AddFeedback(
    IN UserIDParam INT, 
    IN SessionIDParam INT, 
    IN CommentsParam TEXT
)
BEGIN
    INSERT INTO Feedbacks (UserID, SessionID, Comments) 
    VALUES (UserIDParam, SessionIDParam, CommentsParam);
END $$
CALL AddFeedback(4, 4, 'Great session!');
DELIMITER;
-- Procedure to retrieve user feedback
DELIMITER $$
CREATE PROCEDURE GetUserFeedback(IN UserIDParam INT)
BEGIN
    SELECT Users.Name, Feedbacks.Comments 
    FROM Users 
    JOIN Feedbacks ON Users.UserID = Feedbacks.UserID
    WHERE Users.UserID = UserIDParam;
END $$
CALL GetUserFeedback(4);
DELIMITER;
-- Procedure to delete a user and related records
DELIMITER $$
CREATE PROCEDURE DeleteUser(IN UserIDParam INT)
BEGIN
    DELETE FROM Feedbacks WHERE UserID = UserIDParam;
    DELETE FROM Messages WHERE UserID = UserIDParam;
    DELETE FROM Sessions WHERE UserID = UserIDParam;
    DELETE FROM Users WHERE UserID = UserIDParam;
END $$
CALL DeleteUser(4);
DELIMITER;
-- Procedure to update a user's email
DELIMETER $$
CREATE PROCEDURE UpdateUserEmail(IN UserIDParam INT, IN NewEmailParam VARCHAR(255))
BEGIN
    UPDATE Users SET Email = NewEmailParam WHERE UserID = UserIDParam;
END $$
CALL UpdateUserEmail(2, 'newemail@example.com');
DELIMITER ;

-- Trigger: Validate Email Format Before Insert in Users
DELIMITER $$
CREATE TRIGGER before_insert_users
BEFORE INSERT ON Users
FOR EACH ROW
BEGIN
    IF NEW.Email NOT LIKE '%@%.%' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid email format';
    END IF;
END $$
DELIMITER ;

-- Trigger: Log new session after insert
DELIMITER $$
CREATE TRIGGER after_insert_sessions
AFTER INSERT ON Sessions
FOR EACH ROW
BEGIN
    INSERT INTO Messages (MessageID, UserID, SessionID, MessageText)
    VALUES (NEW.SessionID + 1000, NEW.UserID, NEW.SessionID, 'New session started');
END $$
DELIMITER ;

-- Trigger: Prevent empty message updates
DELIMITER $$
CREATE TRIGGER before_update_messages
BEFORE UPDATE ON Messages
FOR EACH ROW
BEGIN
    IF NEW.MessageText = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Message cannot be empty';
    END IF;
END $$
DELIMITER ;

-- Trigger: Log deleted feedbacks
DELIMITER $$
CREATE TRIGGER after_delete_feedbacks
AFTER DELETE ON Feedbacks
FOR EACH ROW
BEGIN
    INSERT INTO Feedback_Audit (FeedbackID, UserID, SessionID)
    VALUES (OLD.FeedbackID, OLD.UserID, OLD.SessionID);
END $$
DELIMITER ;
select *from Feedback;
CREATE USER 'mentalhealth'@'127.0.0.1' IDENTIFIED BY 'Gatali123';

-- Grant full privileges on the database to the new user
GRANT ALL PRIVILEGES ON Mental_Heath_Support.* TO 'mentalhealth'@'localhost';
